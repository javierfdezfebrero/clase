<?php

$servidor="db-pdo";
$usuario="tarefa";
$passwd="Tarefa4.7";
$base="tarefa";

